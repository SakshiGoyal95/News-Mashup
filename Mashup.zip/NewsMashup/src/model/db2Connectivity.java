package model;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;

import com.ibm.db2.jcc.DB2BaseDataSource;
import com.oracle.webservices.internal.api.message.PropertySet.Property;


public class db2Connectivity {
	protected Connection connect = null;
	db2Connectivity(){
		
	}
	public static Connection dbConnector()
	{
	try{
		Class.forName("com.ibm.db2.jcc.DB2Driver");
		Connection connect = DriverManager.getConnection("jdbc:db2://localhost:50000/mashup","owner","sakshi");
		
		return connect;
	}
	
	catch(Exception e){
		return null;
	}
}
}