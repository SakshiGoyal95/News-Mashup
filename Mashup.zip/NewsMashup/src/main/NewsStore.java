package main;


import java.util.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import model.db2Connectivity;

public class NewsStore {
	NewsStore(){
		
	}
	
	public static void store(String field,ArrayList<String> al_title,ArrayList<String> al_link,ArrayList<String> al_desc){
		
		Iterator<String> itr_title = al_title.iterator();
		Iterator<String> itr_link = al_link.iterator();
		Iterator<String> itr_desc = al_desc.iterator();
		try{
			Connection connect = db2Connectivity.dbConnector();
			Statement stmt = connect.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
			while(itr_title.hasNext() && itr_link.hasNext() && itr_desc.hasNext()){
				
					try{
					stmt.executeUpdate("insert into newsfeed values('" + field + "','" + itr_title.next() + "','" + itr_link.next() + "','" + itr_desc.next() + "')" );
					}
					catch(Exception e){
						
					}
			}	
		}
		catch(Exception e){
			System.out.println("an exception occured");
			return;
		}
		
		
		
	}
}
