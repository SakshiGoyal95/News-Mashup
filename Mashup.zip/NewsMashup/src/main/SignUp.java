package main;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Color;

import javax.swing.JButton;

import java.awt.Font;

import javax.swing.JLabel;
import javax.swing.ImageIcon;

import java.awt.GridLayout;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
import javax.swing.JPasswordField;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JList;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import model.db2Connectivity;
public class SignUp extends JFrame {

	private JPanel contentPane,panel_1,panel,panel_2 ;
	private JTextField nameFld;
	private JTextField emailFld;
	private JPasswordField pwdFld;
	private JComboBox comboBox;
	private JLabel label_2,label_3,lblName, lblEmailId, lblPassword,lblNewUserSignup,Preference;
	private JButton btnSubmit; 
	
		SignUp() {
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		setBounds(100, 100, 517, 394);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 250, 250));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		 panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBackground(new Color(240, 255, 255));
		panel_1.setBounds(10, 11, 481, 111);
		contentPane.add(panel_1);
		
		label_2 = new JLabel("News World");
		label_2.setForeground(new Color(0, 128, 128));
		label_2.setFont(new Font("Satisfaction", Font.BOLD, 40));
		label_2.setBounds(143, 11, 335, 89);
		panel_1.add(label_2);
		
		 label_3 = new JLabel("New label");
		label_3.setIcon(new ImageIcon(SignUp.class.getResource("/main/img/Title.gif")));
		label_3.setBounds(10, 5, 101, 101);
		panel_1.add(label_3);
		
		 panel = new JPanel();
		panel.setBackground(new Color(255, 250, 250));
		panel.setBounds(10, 134, 481, 211);
		contentPane.add(panel);
		panel.setLayout(null);
		
		 lblName = new JLabel("Name:");
		lblName.setBounds(49, 62, 46, 23);
		panel.add(lblName);
		
		 lblEmailId = new JLabel("Email ID:");
		lblEmailId.setBounds(49, 87, 62, 23);
		panel.add(lblEmailId);
		
		 lblPassword = new JLabel("Password:");
		lblPassword.setBounds(49, 112, 62, 23);
		panel.add(lblPassword);
		
		panel_2 = new JPanel();
		panel_2.setBackground(new Color(238, 232, 170));
		panel_2.setBounds(10, 0, 461, 40);
		panel.add(panel_2);
		panel_2.setLayout(null);
		
		lblNewUserSignup = new JLabel("New User Sign Up");
		lblNewUserSignup.setForeground(new Color(128, 0, 0));
		lblNewUserSignup.setFont(new Font("Narkisim", Font.BOLD, 18));
		lblNewUserSignup.setBounds(171, 0, 168, 40);
		panel_2.add(lblNewUserSignup);
		
		btnSubmit = new JButton("Submit");
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				check();
				submit();
				dispose();
				
				
			}
		});
		btnSubmit.setBounds(193, 177, 89, 23);
		panel.add(btnSubmit);
		
		nameFld = new JTextField();
		nameFld.setBounds(129, 62, 300, 23);
		panel.add(nameFld);
		nameFld.setColumns(10);
		
		emailFld = new JTextField();
		emailFld.setBounds(129, 87, 300, 23);
		panel.add(emailFld);
		emailFld.setColumns(10);
		
		pwdFld = new JPasswordField();
		pwdFld.setBounds(129, 112, 300, 23);
		panel.add(pwdFld);
		
		Preference = new JLabel("Occupation");
		Preference.setBounds(47, 149, 100, 14);
		panel.add(Preference);
		
		
		
		comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Select--", "Student", "Businessman", "Teacher", "Scientist", "Sportsperson", "Government Employee", "Doctor", "Accountant", "Professor", "Bank Employee", "Share Broker", "Artist", "Traveller", "Politicain", "Magazine Editor", "Engineer", "Lawyer", "Others"}));
		comboBox.setEditable(true);
		comboBox.setBounds(154, 146, 81, 20);
		panel.add(comboBox);
	}

public void submit()
{
     try
    {
    Class.forName("com.ibm.db2.jcc.DB2Driver");
Connection conn = null;
conn =      (Connection) DriverManager.getConnection("jdbc:db2://localhost:50000/mashup","owner","sakshi");

Statement stmt = (Statement) conn.createStatement() ;




stmt.executeUpdate("insert into signup values('"+nameFld.getText()+"','"+emailFld.getText()+"','"+pwdFld.getText()+"','" +comboBox.getSelectedItem()+"')");
	
	JOptionPane.showMessageDialog(null, "you have been signed up");
stmt.close() ;


conn.close() ;

    }
    catch(Exception ex)
    {
      System.out.println( "error in connectivity");
    }

}

public void check()
{
     try
    {
    
Connection conn = db2Connectivity.dbConnector();


Statement stmt = (Statement) conn.createStatement() ;


ResultSet rs;
rs=stmt.executeQuery("select * from signup");
boolean flag=false;
while(rs.next())
{
	if(emailFld.getText().equals(rs.getString(2)) || nameFld.getText().equals(rs.getString(1))  )
	{
		flag=true;
		 JOptionPane.showMessageDialog(null, "Your username or email id is already occupied by someone else");
		
		 new SignUp().setVisible(true);
		System.out.println("run");
		
	}

		
	
		
}

	



	
stmt.close() ;


conn.close() ;
rs.close();
    }
    catch(Exception ex)
    {
      System.out.println( "error in connectivity");
    }

}
}

