package main;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JComboBox;

import java.awt.BorderLayout;

import javax.swing.JLabel;
import javax.swing.JCheckBox;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import java.awt.Dimension;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.Panel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JTextField;
import javax.swing.JPasswordField;
import model.db2Connectivity;
 public class SignIn {

	
	
	
	
	
	
	public static void login(String email,String pwd)
	{
		
	     try
	    {
	    
	Connection conn = db2Connectivity.dbConnector();
	
	
	Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
	
	ResultSet rs;
	rs=stmt.executeQuery("select * from signup");
	boolean s=false;
	String name;
	while(rs.next())
	{
		
		
		if(email.equals(rs.getObject(2)) && pwd.equals(rs.getObject(3)))
		{
			name=rs.getObject(1).toString();
			
			String news="",pref="";
			s=true;
			
			ResultSet rs1=stmt.executeQuery("select preference from signup where emailid='"+email+"'");
			ResultSet rs2;
			rs1.next();
				
			pref=rs1.getString(1);
			
			
			if(pref=="Sportsperson"){
				rs2=stmt.executeQuery("select Link from news where Field='Sports'");
			}
			
			else if(pref=="Teacher" || pref== "Professor" || pref=="Student"){
				rs2=stmt.executeQuery("select Link from news where Field='Education'");
			}
			else if(pref=="Doctor"){
				rs2=stmt.executeQuery("select Link from news where Field='Health'");
			}
			else if(pref=="Politician" || pref=="Government Employee" || pref=="Lawyer"){
				rs2=stmt.executeQuery("select Link from news where Field='Politics'");
			}
			else if(pref=="Scientist"){
				rs2=stmt.executeQuery("select Link from news where Field='Science'");
			}
			else if(pref=="Engineer"){
				rs2=stmt.executeQuery("select Link from news where Field='Health'");
			}
			else if(pref=="Traveller"){
				rs2=stmt.executeQuery("select Link from news where Field='Travel'");
			}
			else if(pref=="Businessman" || pref=="Accountant"){
				rs2=stmt.executeQuery("select Link from news where Field='Business'");
			}
			else if(pref=="Bank Employee" || pref=="Share Broker"){
				rs2=stmt.executeQuery("select Link from news where Field='Money'");
			}
			else if(pref=="Artist"){
				rs2=stmt.executeQuery("select Link from news where Field='Entertainment'");
			}
			else if(pref=="Magazine Editor"){
				rs2=stmt.executeQuery("select Link from news where Field='Magazine'");
			}
			else {
				rs2=stmt.executeQuery("select Link from news where Field='World'");
			}
			
			
			
			while(rs2.next()){
				
				Rss objrss=new Rss();
				
			news+=objrss.readRSS("",rs2.getString(1));
			}
			
			UserWindow uw=new UserWindow(news,name,email);
			
			uw.activate();
			
			
			
			
		}
	}
	if(s==false)
		
			JOptionPane.showMessageDialog(null, "Your email id or password is wrong");
	
	    }
	    catch(Exception ex)
	    {
	    	
	    		
	    }

	}
	
		
	
}
