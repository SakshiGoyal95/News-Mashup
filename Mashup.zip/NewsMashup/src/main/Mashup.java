package main;
import java.awt.*;

import javax.swing.*;

import java.io.*;
import java.net.*;

public class Mashup{

	
		
		public static void main(String[] args) {
	
		
		UI u = new UI();
		u.setVisible(true);
		u.setDefaultCloseOperation(UI.EXIT_ON_CLOSE);
		
		
		
	}}
		
	
		



	
		
		