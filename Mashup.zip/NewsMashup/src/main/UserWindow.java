package main;
import model.db2Connectivity;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import model.db2Connectivity;

public class UserWindow extends JFrame{
	private JButton btnback,btnHomepage,btnDeleteAccount ;
	private BufferedImage img;
	private  JLabel lblNewLabel_1;
	JPanel panel_6;
	private  String emailid;
	UserWindow(String s,String name,String email){
		emailid=email;
		getContentPane().setBackground(new Color(0, 0, 0));
	    setSize(new Dimension(1367, 740));
		getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(240, 255, 255));
		panel.setBounds(10, 11, 1331, 111);
		getContentPane().add(panel);
		panel.setLayout(null);
		
		panel_6 = new JPanel();
		panel_6.setBackground(new Color(204, 255, 102));
		panel_6.setBounds(1038, 5, 283, 101);
		panel.add(panel_6);
		panel_6.setLayout(null);
		
				
		btnback = new JButton("SIGN OUT");
		btnback.setBackground(new Color(255, 255, 102));
		btnback.setFont(new Font("Calibri", Font.PLAIN, 14));
		btnback.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnback.setBounds(163, 75, 110, 21);
		panel_6.add(btnback);
		btnback.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				UI u = new UI();
				setVisible(false);
				u.setVisible(true);
				u.setDefaultCloseOperation(UI.EXIT_ON_CLOSE);
			}
		});
		
		JLabel lblWelcome = new JLabel("Welcome");
		lblWelcome.setFont(new Font("Stencil", Font.PLAIN, 18));
		lblWelcome.setBounds(10, 11, 89, 55);
		panel_6.add(lblWelcome);
		
		JLabel lblNewLabel = new JLabel(name);
		lblNewLabel.setFont(new Font("Stencil", Font.PLAIN, 18));
		lblNewLabel.setBounds(118, 11, 155, 55);
		panel_6.add(lblNewLabel);
		
		btnHomepage = new JButton("HOMEPAGE");
		btnHomepage.setFont(new Font("Calibri", Font.PLAIN, 14));
		btnHomepage.setBackground(new Color(255, 255, 102));
		btnHomepage.setBounds(10, 75, 140, 21);
		panel_6.add(btnHomepage);
		btnHomepage.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				UI u = new UI();
				(u.panel_6).setVisible(false);
				(u.panel).add(panel_6);
				panel_6.remove(btnHomepage);				
				setVisible(false);
				u.setVisible(true);
				u.setDefaultCloseOperation(UI.EXIT_ON_CLOSE);
			}
		});
		
		
		JLabel lblNewsWorld = new JLabel("News World");
		lblNewsWorld.setForeground(new Color(0, 128, 128));
		lblNewsWorld.setFont(new Font("Satisfaction", Font.BOLD, 40));
		lblNewsWorld.setBounds(121, 11, 357, 89);
		panel.add(lblNewsWorld);
		
		
		lblNewLabel_1 = new JLabel("New label");
		try{
			img = ImageIO.read(new File("C:/Users/owner/workspace/NewsMashup/src/main/img/Title.gif"));
		}
		catch(IOException ioe){
			
		}
		lblNewLabel_1.setIcon(new ImageIcon(img));
		lblNewLabel_1.setBounds(10, 5, 101, 101);
		panel.add(lblNewLabel_1);
		

		TextArea textArea = new TextArea();
		textArea.setEditable(false);
		textArea.setBounds(80, 178, 1185, 474);
		getContentPane().add(textArea);
		textArea.setText(s);
		textArea.setFont(new Font("Dialog", Font.PLAIN, 14));
		
		btnDeleteAccount = new JButton("Delete Account");
		btnDeleteAccount.setBounds(1252, 658, 89, 23);
		getContentPane().add(btnDeleteAccount);
		ButtonHandler bh=new ButtonHandler();
		btnDeleteAccount.addActionListener(bh);
	}
	class ButtonHandler implements ActionListener{
		
		int m=1;
		public void actionPerformed(ActionEvent e) {
			try{
			Connection conn = db2Connectivity.dbConnector();
			
			
			Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
			if(e.getSource()==btnDeleteAccount){
				JOptionPane.showMessageDialog(null, "Are you sure?");
				m=JOptionPane.OK_OPTION;
				
				if(m==0){
					stmt.executeUpdate("delete from signup where emailid='"+emailid+"'");
					setVisible(false);
				}
			}
			}catch(Exception ex){
				System.out.println("An exception occured");
			}
		}
	}
public void activate(){
		
		setSize(new Dimension(1367, 740));;
		setVisible(true);
		setDefaultCloseOperation(UI.EXIT_ON_CLOSE);
	}
}
