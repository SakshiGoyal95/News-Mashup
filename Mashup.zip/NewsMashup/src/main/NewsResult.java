package main;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.*;

public class NewsResult extends JFrame {
	private JButton btnback;
	private JLabel lblNewLabel_1,lblNewsWorld;
	private BufferedImage img;
	UI u;
	
	NewsResult(String s,String field){
		getContentPane().setBackground(new Color(0, 0, 0));
	    setSize(new Dimension(1367, 740));
		getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(240, 255, 255));
		panel.setBounds(10, 11, 1331, 111);
		getContentPane().add(panel);
		panel.setLayout(null);
	

		btnback = new JButton("Back");
		btnback.setBackground(new Color(240, 248, 255));
		btnback.setFont(new Font("Calibri", Font.PLAIN, 16));
		btnback.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnback.setBounds(121, 4, 70, 30);
		panel.add(btnback);
		
		lblNewsWorld = new JLabel("News World");
		lblNewsWorld.setForeground(new Color(0, 128, 128));
		lblNewsWorld.setFont(new Font("Satisfaction", Font.BOLD, 40));
		lblNewsWorld.setBounds(121, 11, 357, 89);
		panel.add(lblNewsWorld);
		
		
		lblNewLabel_1 = new JLabel("New label");
		try{
			img = ImageIO.read(new File("C:/Users/owner/workspace/NewsMashup/src/main/img/Title.gif"));
		}
		catch(IOException ioe){
			
		}
		lblNewLabel_1.setIcon(new ImageIcon(img));
		lblNewLabel_1.setBounds(10, 5, 101, 101);
		panel.add(lblNewLabel_1);	
		
		JLabel lblNewLabel = new JLabel(field);
		lblNewLabel.setForeground(new Color(51, 51, 153));
		lblNewLabel.setFont(new Font("Rockwell", Font.BOLD, 26));
		lblNewLabel.setBounds(1008, 27, 277, 57);
		panel.add(lblNewLabel);
	
		

		TextArea textArea = new TextArea();
		textArea.setEditable(false);
		textArea.setBounds(80, 178, 1185, 474);
		getContentPane().add(textArea);
		textArea.setText(s);
		textArea.setFont(new Font("Dialog", Font.PLAIN, 14));
		
		ButtonHandler bh = new ButtonHandler();
		btnback.addActionListener(bh);
	}
	
	public void activate(){
		
		setSize(new Dimension(1367, 740));;
		setVisible(true);
		setDefaultCloseOperation(UI.EXIT_ON_CLOSE);
	}
	
public class ButtonHandler implements ActionListener{
				
		public void actionPerformed(ActionEvent e){
			try{
				if(e.getSource()==btnback){
					setVisible(false);
					u = new UI();
					u.setVisible(true);
					u.setDefaultCloseOperation(UI.EXIT_ON_CLOSE);
					}
				
									
			}
			catch(Exception ex){
				System.out.println(" \n an exception occured");
			}
			
		}
}
}

