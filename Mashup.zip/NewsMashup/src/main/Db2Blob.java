package main;
import model.db2Connectivity;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.io.*;
import java.sql.*;

import javax.imageio.ImageIO;

public class Db2Blob {
	
	
	Db2Blob(){
		Db2Blob.storeImg("Money", "C:/Users/owner/workspace/NewsMashup/src/main/img/Money.jpg");
		Db2Blob.storeImg("Travel", "C:/Users/owner/workspace/NewsMashup/src/main/img/Travel.jpg");
		Db2Blob.storeImg("Health", "C:/Users/owner/workspace/NewsMashup/src/main/img/Health.png");
		Db2Blob.storeImg("Science", "C:/Users/owner/workspace/NewsMashup/src/main/img/Science.jpg");
		Db2Blob.storeImg("Magazine", "C:/Users/owner/workspace/NewsMashup/src/main/img/Magazine.jpg");
		Db2Blob.storeImg("Title", "C:/Users/owner/workspace/NewsMashup/src/main/img/Title.gif");
		Db2Blob.storeImg("World", "C:/Users/owner/workspace/NewsMashup/src/main/img/World.jpg");
		Db2Blob.storeImg("Business", "C:/Users/owner/workspace/NewsMashup/src/main/img/Business.jpg");
		Db2Blob.storeImg("Sports", "C:/Users/owner/workspace/NewsMashup/src/main/img/Sports.jpg");
		Db2Blob.storeImg("Politics", "C:/Users/owner/workspace/NewsMashup/src/main/img/Politics.jpg");
		Db2Blob.storeImg("Technology", "C:/Users/owner/workspace/NewsMashup/src/main/img/Technology.jpg");
		Db2Blob.storeImg("Entertainment", "C:/Users/owner/workspace/NewsMashup/src/main/img/Entertainment.jpg");
		Db2Blob.storeImg("Education", "C:/Users/owner/workspace/NewsMashup/src/main/img/Education.jpg");

		
	}
	
	public static void storeImg(String field,String filepath){
		
			
			
		try{
			Connection con= db2Connectivity.dbConnector();
			
			
	         PreparedStatement pstmt = con.prepareStatement("INSERT INTO images VALUES(?,?,?)");
	         pstmt.setString(1, field);
	         pstmt.setBytes(2,readImage(filepath));
	         pstmt.setString(3,filepath);
	         pstmt.executeUpdate();
	         
		}
		catch(Exception e){
			System.out.println("Dsadsfsdf");
			
		}
	
	}
	
	public static Blob getImage(){
		
	       try {
	    	   Connection con= db2Connectivity.dbConnector();
	   		Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
	   		 ResultSet rs=stmt.executeQuery("select * from images");
	   		 
	   	      
	    	   while(rs.next()){
	    		   Blob b= rs.getBlob(2);
	    		  
	           
	    	   return b;
	    	   }   
	       }
	       catch(Exception ex){
	    	   System.out.println(" an exception occured");
	    	   return null;
	    	   
	       }
		return null;
	}
	
	 private static byte[] readImage(String filename) {

	      byte[]  imageData = null;
	      FileInputStream file = null;
	      try {
	           file = new FileInputStream(filename);
	           int size = file.available();
	           imageData = new byte[size];
	           file.read(imageData);
	      } catch (FileNotFoundException e) {
	           e.printStackTrace();
	               } catch (IOException e) {
	           e.printStackTrace();
	      } finally {
	           try {
	                if (file != null) file.close();
	               } catch (IOException e) {
	            	   System.out.println(" an input output exception occured");
	                e.printStackTrace();
	                 }
	             }
	          return imageData;
	      }
}
