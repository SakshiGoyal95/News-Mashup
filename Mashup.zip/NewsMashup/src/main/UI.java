package main;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.awt.image.BufferedImageOp;
import java.awt.image.ColorModel;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.imageio.ImageIO;
import javax.swing.*;

import model.db2Connectivity;



public class UI extends JFrame {

	private JPanel  panel_1, panel_9 ,  panel_10, panel_11, panel_12, panel_13, panel_14, panel_4, panel_5, panel_2, panel_21, panel_7, panel_8, panel_3, panel_15, panel_16, panel_17, panel_18, panel_19, panel_20, panel_22, panel_23, panel_24, panel_25, panel_26, panel_27, panel_28, panel_29, panel_30, panel_31, panel_32, panel_33, panel_34, panel_35, panel_36, panel_37 ;
	private JButton btnSignUp,btnCancel, btnSignIn, btnWorld, btnBusiness, btnSports, btnScience, btnTechnology, btnEntertainment, btnTopNews, btnMostRead, btnThisWeek, btnPrimeTime, btnEducation, btnMoney, btnTravel, btnHealth, btnPolitics, btnMagazine, btnSearch, btnHome;
	private JLabel lblNewLabel_1, lblNewUser, lblAlreadyRegistered, lblNewsWorld, lblEmailId, lblPassword, label_2, label_3, label_4, label_5, label_6, label_7, lblNewLabel, label_14, label, label_1, label_8, label_9, label_10, label_11, label_12, label_13;
	private JTextField jtf_search, textField, textField_1;
	private JPasswordField passwordField;
	private JTextArea textArea;
	private JScrollPane scrollPane;
	JPanel panel,panel_6;
	
	UI(){
	 
		try{
		BufferedImage img=null;
		
		getContentPane().setBackground(new Color(0, 0, 0));
		setSize(new Dimension(1367, 740));
		getContentPane().setLayout(null);
		
		panel = new JPanel();
		panel.setBackground(new Color(240, 255, 255));
		panel.setBounds(10, 11, 1331, 111);
		getContentPane().add(panel);
		panel.setLayout(null);
		
		panel_6 = new JPanel();
		panel_6.setBackground(new Color(204, 255, 102));
		panel_6.setBounds(1038, 5, 283, 77);
		panel.add(panel_6);
		panel_6.setLayout(null);
		
		btnSignUp = new JButton("Sign Up");
		btnSignUp.setBackground(new Color(255, 255, 102));
		btnSignUp.setFont(new Font("Calibri", Font.PLAIN, 14));
		btnSignUp.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnSignUp.setBounds(182, 46, 89, 23);
		panel_6.add(btnSignUp);
		
		lblNewUser = new JLabel("New User?");
		lblNewUser.setFont(new Font("SoundLight", Font.PLAIN, 12));
		lblNewUser.setBounds(82, 47, 120, 19);
		panel_6.add(lblNewUser);
		
		btnSignIn = new JButton("Sign In");
		
		btnSignIn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
					
			panel_6.setVisible(false);
			
			panel_7 = new JPanel();
			panel_7.setBackground(new Color(204, 255, 102));
			panel_7.setBounds(1038, 5, 283, 101);
			panel.add(panel_7);
			panel_7.setLayout(null);
			
			
			
			btnCancel = new JButton("Cancel");
			btnCancel.setBackground(new Color(255, 255, 102));
			btnCancel.setFont(new Font("Calibri", Font.PLAIN, 14));
			btnCancel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			btnCancel.setBounds(184, 67, 89, 23);
			panel_7.add(btnCancel);
			btnCancel.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					panel_6.setVisible(true);
					panel_7.setVisible(false);
					
					
					
				}
			});
			
			
			btnSignUp = new JButton("Sign In");
			btnSignUp.setBackground(new Color(255, 255, 102));
			btnSignUp.setFont(new Font("Calibri", Font.PLAIN, 14));
			btnSignUp.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			btnSignUp.setBounds(90, 67, 89, 23);
			panel_7.add(btnSignUp);
			btnSignUp.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					
					SignIn.login(textField.getText(),passwordField.getText());
					
					
				}
			});
			
			lblEmailId = new JLabel("Email ID:");
			lblEmailId.setFont(new Font("Calibri", Font.BOLD, 13));
			lblEmailId.setBounds(10, 11, 68, 23);
			panel_7.add(lblEmailId);
			
			lblPassword = new JLabel("Password:");
			lblPassword.setFont(new Font("Calibri", Font.BOLD, 13));
			lblPassword.setBounds(10, 36, 68, 23);
			panel_7.add(lblPassword);
			
			textField = new JTextField();
			textField.setBounds(88, 12, 185, 20);
			panel_7.add(textField);
			textField.setColumns(10);
			
			passwordField = new JPasswordField();
			passwordField.setBounds(88, 37, 185, 20);
			panel_7.add(passwordField);
			
					
					
				
			
			
			}
		});
		btnSignIn.setBackground(new Color(255, 255, 102));
		btnSignIn.setFont(new Font("Calibri", Font.PLAIN, 14));
		btnSignIn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnSignIn.setBounds(182, 11, 89, 23);
		panel_6.add(btnSignIn);
		
		lblAlreadyRegistered = new JLabel("Already Registered?");
		lblAlreadyRegistered.setFont(new Font("SoundLight", Font.PLAIN, 12));
		lblAlreadyRegistered.setBounds(51, 11, 120, 21);
		panel_6.add(lblAlreadyRegistered);
		
		lblNewsWorld = new JLabel("News World");
		lblNewsWorld.setForeground(new Color(0, 128, 128));
		lblNewsWorld.setFont(new Font("Satisfaction", Font.BOLD, 40));
		lblNewsWorld.setBounds(121, 11, 357, 89);
		panel.add(lblNewsWorld);
		
		lblNewLabel_1 = new JLabel("New label");
		img = ImageIO.read(new File("C:/Users/owner/workspace/NewsMashup/src/main/img/Title.gif"));
		lblNewLabel_1.setIcon(new ImageIcon(img));
		lblNewLabel_1.setBounds(10, 5, 101, 101);
		panel.add(lblNewLabel_1);		
		
		panel_2 = new JPanel();
		panel_2.setBackground(Color.BLACK);
		panel_2.setBounds(10, 184, 1331, 506);
		getContentPane().add(panel_2);
		panel_2.setLayout(null);
		
		panel_1 = new JPanel();
		panel_1.setBounds(0, 33, 1331, 208);
		panel_2.add(panel_1);
		panel_1.setBackground(new Color(0, 0, 0));
		panel_1.setLayout(new GridLayout(0, 6, 0, 0));
		
		panel_7 = new JPanel();
		panel_7.setBackground(new Color(240, 255, 255));
		panel_7.setBounds(767, 77, 262, 23);
		panel.add(panel_7);
		panel_7.setLayout(null);
		
		textField_1 = new JTextField();
		textField_1.setBounds(0, 0, 163, 23);
		panel_7.add(textField_1);
		textField_1.setToolTipText("Enter the Search Topic");
		textField_1.setColumns(10);
		
		btnSearch = new JButton("Search");
		
		btnSearch.setFont(new Font("Calibri", Font.PLAIN, 14));
		btnSearch.setBackground(Color.WHITE);
		btnSearch.setBounds(173, 0, 89, 23);
		panel_7.add(btnSearch);
		
		panel_9 = new JPanel();
		panel_9.setBackground(new Color(0, 0, 0));
		panel_9.setLayout(null);
		panel_1.add(panel_9);
		
		btnWorld = new JButton("World");
		btnWorld.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				panel_1.setVisible(false);
				panel_2.setVisible(false);
								
				panel_21 = new JPanel();
				panel_21.setBackground(Color.BLACK);
				panel_21.setBounds(10, 123, 1331, 578);
				getContentPane().add(panel_21);
				panel_21.setLayout(null);
				
				scrollPane = new JScrollPane();
				scrollPane.setBounds(10, 63, 1311, 504);
				panel_21.add(scrollPane);
				
				textArea = new JTextArea();
				textArea.setWrapStyleWord(true);
				textArea.setMargin(new Insets(10, 10, 10, 7));
				scrollPane.setViewportView(textArea);
				textArea.setLineWrap(true);
				textArea.setEditable(false);
				
			}
		});
		btnWorld.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnWorld.setBounds(66, 167, 89, 23);
		panel_9.add(btnWorld);
		
		label_2 = new JLabel("");
		img = ImageIO.read(new File("C:/Users/owner/workspace/NewsMashup/src/main/img/World.jpg"));
		label_2.setIcon(new ImageIcon(img));
		label_2.setBounds(32, 0, 156, 156);
		panel_9.add(label_2);
		
		panel_10 = new JPanel();
		panel_10.setBackground(new Color(0, 0, 0));
		panel_10.setLayout(null);
		panel_1.add(panel_10);
		
		btnBusiness = new JButton("Business");
		btnBusiness.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				panel_1.setVisible(false);
				panel_2.setVisible(false);
								
				panel_22 = new JPanel();
				panel_22.setBackground(Color.BLACK);
				panel_22.setBounds(10, 123, 1331, 578);
				getContentPane().add(panel_22);
				panel_22.setLayout(null);
				
				scrollPane = new JScrollPane();
				scrollPane.setBounds(10, 63, 1311, 504);
				panel_22.add(scrollPane);
				
				textArea = new JTextArea();
				textArea.setWrapStyleWord(true);
				textArea.setMargin(new Insets(10, 10, 10, 7));
				scrollPane.setViewportView(textArea);
				textArea.setLineWrap(true);
				textArea.setEditable(false);
			}
		});
		btnBusiness.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnBusiness.setBounds(66, 167, 89, 23);
		panel_10.add(btnBusiness);
		
		label_3 = new JLabel("");
		img = ImageIO.read(new File("C:/Users/owner/workspace/NewsMashup/src/main/img/Business.jpg"));
		label_3.setIcon(new ImageIcon(img));
		label_3.setBounds(32, 0, 156, 156);
		panel_10.add(label_3);
		
		panel_11 = new JPanel();
		panel_11.setBackground(new Color(0, 0, 0));
		panel_11.setLayout(null);
		panel_1.add(panel_11);
		
		btnSports = new JButton("Sports");
		btnSports.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				panel_1.setVisible(false);
				panel_2.setVisible(false);
								
				panel_23 = new JPanel();
				panel_23.setBackground(Color.BLACK);
				panel_23.setBounds(10, 123, 1331, 578);
				getContentPane().add(panel_23);
				panel_23.setLayout(null);
				
				scrollPane = new JScrollPane();
				scrollPane.setBounds(10, 63, 1311, 504);
				panel_23.add(scrollPane);
				
				textArea = new JTextArea();
				textArea.setWrapStyleWord(true);
				textArea.setMargin(new Insets(10, 10, 10, 7));
				scrollPane.setViewportView(textArea);
				textArea.setLineWrap(true);
				textArea.setEditable(false);
			}
		});
		btnSports.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnSports.setBounds(66, 167, 89, 23);
		panel_11.add(btnSports);
		
		label_4 = new JLabel("");
		img = ImageIO.read(new File("C:/Users/owner/workspace/NewsMashup/src/main/img/Sports.jpg"));
		label_4.setIcon(new ImageIcon(img));
		label_4.setBounds(32, 0, 156, 156);
		panel_11.add(label_4);
		
		panel_12 = new JPanel();
		panel_12.setBackground(new Color(0, 0, 0));
		panel_12.setLayout(null);
		panel_1.add(panel_12);
		
		btnPolitics = new JButton("Politics");
		btnPolitics.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				panel_1.setVisible(false);
				panel_2.setVisible(false);
								
				panel_24 = new JPanel();
				panel_24.setBackground(Color.BLACK);
				panel_24.setBounds(10, 123, 1331, 578);
				getContentPane().add(panel_24);
				panel_24.setLayout(null);
				
				scrollPane = new JScrollPane();
				scrollPane.setBounds(10, 63, 1311, 504);
				panel_24.add(scrollPane);
				
				textArea = new JTextArea();
				textArea.setWrapStyleWord(true);
				textArea.setMargin(new Insets(10, 10, 10, 7));
				scrollPane.setViewportView(textArea);
				textArea.setLineWrap(true);
				textArea.setEditable(false);
			}
		});
		btnPolitics.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnPolitics.setBounds(66, 167, 89, 23);
		panel_12.add(btnPolitics);
		
		label_5 = new JLabel("");
		img = ImageIO.read(new File("C:/Users/owner/workspace/NewsMashup/src/main/img/Politics.jpg"));
		label_5.setIcon(new ImageIcon(img));
		label_5.setBounds(32, 0, 156, 156);
		panel_12.add(label_5);
		
		panel_13 = new JPanel();
		panel_13.setBackground(new Color(0, 0, 0));
		panel_13.setLayout(null);
		panel_1.add(panel_13);
		
		btnTechnology = new JButton("Technology");
		btnTechnology.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				panel_1.setVisible(false);
				panel_2.setVisible(false);
								
				panel_25 = new JPanel();
				panel_25.setBackground(Color.BLACK);
				panel_25.setBounds(10, 123, 1331, 578);
				getContentPane().add(panel_25);
				panel_25.setLayout(null);
				
				scrollPane = new JScrollPane();
				scrollPane.setBounds(10, 63, 1311, 504);
				panel_25.add(scrollPane);
				
				textArea = new JTextArea();
				textArea.setWrapStyleWord(true);
				textArea.setMargin(new Insets(10, 10, 10, 7));
				scrollPane.setViewportView(textArea);
				textArea.setLineWrap(true);
				textArea.setEditable(false);
			}
		});
		btnTechnology.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnTechnology.setBounds(57, 167, 105, 23);
		panel_13.add(btnTechnology);
		
		label_6 = new JLabel("");
		img = ImageIO.read(new File("C:/Users/owner/workspace/NewsMashup/src/main/img/Technology.jpg"));
		label_6.setIcon(new ImageIcon(img));
		label_6.setBounds(32, 0, 156, 156);
		panel_13.add(label_6);
		
		panel_14 = new JPanel();
		panel_14.setBackground(new Color(0, 0, 0));
		panel_14.setLayout(null);
		panel_1.add(panel_14);
		
		btnEntertainment = new JButton("Entertainment");
		btnEntertainment.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				panel_1.setVisible(false);
				panel_2.setVisible(false);
								
				panel_26 = new JPanel();
				panel_26.setBackground(Color.BLACK);
				panel_26.setBounds(10, 123, 1331, 578);
				getContentPane().add(panel_26);
				panel_26.setLayout(null);
				
				scrollPane = new JScrollPane();
				scrollPane.setBounds(10, 63, 1311, 504);
				panel_26.add(scrollPane);
				
				textArea = new JTextArea();
				textArea.setWrapStyleWord(true);
				textArea.setMargin(new Insets(10, 10, 10, 7));
				scrollPane.setViewportView(textArea);
				textArea.setLineWrap(true);
				textArea.setEditable(false);
			}
		});
		btnEntertainment.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnEntertainment.setBounds(42, 167, 125, 23);
		panel_14.add(btnEntertainment);
		
		label_7 = new JLabel("");
		img = ImageIO.read(new File("C:/Users/owner/workspace/NewsMashup/src/main/img/Entertainment.jpg"));
		label_7.setIcon(new ImageIcon(img));
		label_7.setBounds(32, 0, 156, 156);
		panel_14.add(label_7);
		
		panel_3 = new JPanel();
		panel_3.setBounds(0, 275, 1331, 208);
		panel_2.add(panel_3);
		panel_3.setBackground(new Color(0, 0, 0));
		panel_3.setLayout(new GridLayout(0, 6, 0, 0));
		
		panel_15 = new JPanel();
		panel_15.setBackground(new Color(0, 0, 0));
		panel_15.setLayout(null);
		panel_3.add(panel_15);
		
		btnEducation = new JButton("Education");
		btnEducation.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				panel_1.setVisible(false);
				panel_2.setVisible(false);
								
				panel_27 = new JPanel();
				panel_27.setBackground(Color.BLACK);
				panel_27.setBounds(10, 123, 1331, 578);
				getContentPane().add(panel_27);
				panel_27.setLayout(null);
				
				scrollPane = new JScrollPane();
				scrollPane.setBounds(10, 63, 1311, 504);
				panel_27.add(scrollPane);
				
				textArea = new JTextArea();
				textArea.setWrapStyleWord(true);
				textArea.setMargin(new Insets(10, 10, 10, 7));
				scrollPane.setViewportView(textArea);
				textArea.setLineWrap(true);
				textArea.setEditable(false);
			}
		});
		btnEducation.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnEducation.setBounds(58, 167, 104, 23);
		panel_15.add(btnEducation);
		
		label_8 = new JLabel("");
		img = ImageIO.read(new File("C:/Users/owner/workspace/NewsMashup/src/main/img/Education.jpg"));
		label_8.setIcon(new ImageIcon(img));
		label_8.setBounds(32, 0, 156, 156);
		panel_15.add(label_8);
		
		panel_16 = new JPanel();
		panel_16.setBackground(new Color(0, 0, 0));
		panel_16.setLayout(null);
		panel_3.add(panel_16);
		
		btnMoney = new JButton("Money");
		btnMoney.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				panel_1.setVisible(false);
				panel_2.setVisible(false);
								
				panel_28 = new JPanel();
				panel_28.setBackground(Color.BLACK);
				panel_28.setBounds(10, 123, 1331, 578);
				getContentPane().add(panel_28);
				panel_28.setLayout(null);
				
				scrollPane = new JScrollPane();
				scrollPane.setBounds(10, 63, 1311, 504);
				panel_28.add(scrollPane);
				
				textArea = new JTextArea();
				textArea.setWrapStyleWord(true);
				textArea.setMargin(new Insets(10, 10, 10, 7));
				scrollPane.setViewportView(textArea);
				textArea.setLineWrap(true);
				textArea.setEditable(false);
			}
		});
		btnMoney.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnMoney.setBounds(66, 167, 89, 23);
		panel_16.add(btnMoney);
		
		label_9 = new JLabel("");
		img = ImageIO.read(new File("C:/Users/owner/workspace/NewsMashup/src/main/img/Money.jpg"));
		label_9.setIcon(new ImageIcon(img));
		label_9.setBounds(32, 0, 156, 156);
		panel_16.add(label_9);
		
		panel_17 = new JPanel();
		panel_17.setBackground(new Color(0, 0, 0));
		panel_17.setLayout(null);
		panel_3.add(panel_17);
		
		btnTravel = new JButton("Travel");
		btnTravel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				panel_1.setVisible(false);
				panel_2.setVisible(false);
								
				panel_29 = new JPanel();
				panel_29.setBackground(Color.BLACK);
				panel_29.setBounds(10, 123, 1331, 578);
				getContentPane().add(panel_29);
				panel_29.setLayout(null);
				
				scrollPane = new JScrollPane();
				scrollPane.setBounds(10, 63, 1311, 504);
				panel_29.add(scrollPane);
				
				textArea = new JTextArea();
				textArea.setWrapStyleWord(true);
				textArea.setMargin(new Insets(10, 10, 10, 7));
				scrollPane.setViewportView(textArea);
				textArea.setLineWrap(true);
				textArea.setEditable(false);
			}
		});
		btnTravel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnTravel.setBounds(67, 167, 89, 23);
		panel_17.add(btnTravel);
		
		label_10 = new JLabel("");
		img = ImageIO.read(new File("C:/Users/owner/workspace/NewsMashup/src/main/img/Travel.jpg"));
		label_10.setIcon(new ImageIcon(img));
		label_10.setBounds(32, 0, 156, 156);
		panel_17.add(label_10);
		
		panel_18 = new JPanel();
		panel_18.setBackground(new Color(0, 0, 0));
		panel_18.setLayout(null);
		panel_3.add(panel_18);
		
		btnHealth = new JButton("Health");
		btnHealth.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				panel_1.setVisible(false);
				panel_2.setVisible(false);
								
				panel_30 = new JPanel();
				panel_30.setBackground(Color.BLACK);
				panel_30.setBounds(10, 123, 1331, 578);
				getContentPane().add(panel_30);
				panel_30.setLayout(null);
				
				scrollPane = new JScrollPane();
				scrollPane.setBounds(10, 63, 1311, 504);
				panel_30.add(scrollPane);
				
				textArea = new JTextArea();
				textArea.setWrapStyleWord(true);
				textArea.setMargin(new Insets(10, 10, 10, 7));
				scrollPane.setViewportView(textArea);
				textArea.setLineWrap(true);
				textArea.setEditable(false);
			}
		});
		btnHealth.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnHealth.setBounds(67, 167, 89, 23);
		panel_18.add(btnHealth);
		
		label_11 = new JLabel("");
		img = ImageIO.read(new File("C:/Users/owner/workspace/NewsMashup/src/main/img/Health.png"));
		label_11.setIcon(new ImageIcon(img));
		label_11.setBounds(32, 0, 156, 156);
		panel_18.add(label_11);
		
		panel_19 = new JPanel();
		panel_19.setBackground(new Color(0, 0, 0));
		panel_19.setLayout(null);
		panel_3.add(panel_19);
		
		btnScience = new JButton("Science");
		btnScience.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				panel_1.setVisible(false);
				panel_2.setVisible(false);
								
				panel_31 = new JPanel();
				panel_31.setBackground(Color.BLACK);
				panel_31.setBounds(10, 123, 1331, 578);
				getContentPane().add(panel_31);
				panel_31.setLayout(null);
				
				scrollPane = new JScrollPane();
				scrollPane.setBounds(10, 63, 1311, 504);
				panel_31.add(scrollPane);
				
				textArea = new JTextArea();
				textArea.setWrapStyleWord(true);
				textArea.setMargin(new Insets(10, 10, 10, 7));
				scrollPane.setViewportView(textArea);
				textArea.setLineWrap(true);
				textArea.setEditable(false);
			}
		});
		btnScience.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnScience.setBounds(66, 167, 89, 23);
		panel_19.add(btnScience);
		
		label_12 = new JLabel("");
		img = ImageIO.read(new File("C:/Users/owner/workspace/NewsMashup/src/main/img/Science.jpg"));
		label_12.setIcon(new ImageIcon(img));
		label_12.setBounds(32, 0, 156, 156);
		panel_19.add(label_12);
		
		panel_20 = new JPanel();
		panel_20.setBackground(new Color(0, 0, 0));
		panel_20.setLayout(null);
		panel_3.add(panel_20);
		
		btnMagazine = new JButton("Magazine");
		btnMagazine.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				panel_1.setVisible(false);
				panel_2.setVisible(false);
								
				panel_32 = new JPanel();
				panel_32.setBackground(Color.BLACK);
				panel_32.setBounds(10, 123, 1331, 578);
				getContentPane().add(panel_32);
				panel_32.setLayout(null);
				
				scrollPane = new JScrollPane();
				scrollPane.setBounds(10, 63, 1311, 504);
				panel_32.add(scrollPane);
				
				textArea = new JTextArea();
				textArea.setWrapStyleWord(true);
				textArea.setMargin(new Insets(10, 10, 10, 7));
				scrollPane.setViewportView(textArea);
				textArea.setLineWrap(true);
				textArea.setEditable(false);
			}
		});
		btnMagazine.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnMagazine.setBounds(66, 167, 89, 23);
		panel_20.add(btnMagazine);
		
		label_13 = new JLabel("");
		img = ImageIO.read(new File("C:/Users/owner/workspace/NewsMashup/src/main/img/Magazine.jpg"));
		label_13.setIcon(new ImageIcon(img));
		label_13.setBounds(32, 0, 156, 156);
		panel_20.add(label_13);
		
		panel_4 = new JPanel();
		panel_4.setBounds(10, 223, 863, -77);
		getContentPane().add(panel_4);
		
		panel_5 = new JPanel();
		panel_5.setBackground(new Color(0, 0, 0));
		panel_5.setBounds(10, 133, 1331, 40);
		getContentPane().add(panel_5);
		
		btnPrimeTime = new JButton("Prime Time");
		btnPrimeTime.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				panel_1.setVisible(false);
				panel_2.setVisible(false);
								
				panel_33 = new JPanel();
				panel_33.setBackground(Color.BLACK);
				panel_33.setBounds(10, 123, 1331, 578);
				getContentPane().add(panel_33);
				panel_33.setLayout(null);
				
				scrollPane = new JScrollPane();
				scrollPane.setBounds(10, 63, 1311, 504);
				panel_33.add(scrollPane);
				
				textArea = new JTextArea();
				textArea.setWrapStyleWord(true);
				textArea.setMargin(new Insets(10, 10, 10, 7));
				scrollPane.setViewportView(textArea);
				textArea.setLineWrap(true);
				textArea.setEditable(false);
				
			}
		});
		
		btnHome = new JButton("Home");
		btnHome.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				panel_1.setVisible(true);
				panel_2.setVisible(true);				
			}
		});
		panel_5.setLayout(new GridLayout(0, 5, 0, 0));
		btnHome.setForeground(new Color(250, 250, 210));
		btnHome.setFont(new Font("Extreme", Font.BOLD, 20));
		btnHome.setBackground(new Color(0, 128, 128));
		panel_5.add(btnHome);
		btnPrimeTime.setForeground(new Color(250, 250, 210));
		btnPrimeTime.setFont(new Font("Extreme", Font.BOLD, 20));
		btnPrimeTime.setBackground(new Color(0, 128, 128));
		panel_5.add(btnPrimeTime);
		btnPrimeTime.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		
		btnThisWeek = new JButton("This Week");
		btnThisWeek.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				panel_1.setVisible(false);
				panel_2.setVisible(false);
								
				panel_34 = new JPanel();
				panel_34.setBackground(Color.BLACK);
				panel_34.setBounds(10, 123, 1331, 578);
				getContentPane().add(panel_34);
				panel_34.setLayout(null);
				
				scrollPane = new JScrollPane();
				scrollPane.setBounds(10, 63, 1311, 504);
				panel_34.add(scrollPane);
				
				textArea = new JTextArea();
				textArea.setWrapStyleWord(true);
				textArea.setMargin(new Insets(10, 10, 10, 7));
				scrollPane.setViewportView(textArea);
				textArea.setLineWrap(true);
				textArea.setEditable(false);
				
			}
		});
		btnThisWeek.setForeground(new Color(250, 250, 210));
		btnThisWeek.setFont(new Font("Extreme", Font.BOLD, 20));
		btnThisWeek.setBackground(new Color(0, 128, 128));
		panel_5.add(btnThisWeek);
		btnThisWeek.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		
		btnMostRead = new JButton("Most Read");
		btnMostRead.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				panel_1.setVisible(false);
				panel_2.setVisible(false);
								
				panel_35 = new JPanel();
				panel_35.setBackground(Color.BLACK);
				panel_35.setBounds(10, 123, 1331, 578);
				getContentPane().add(panel_35);
				panel_35.setLayout(null);
				
				scrollPane = new JScrollPane();
				scrollPane.setBounds(10, 63, 1311, 504);
				panel_35.add(scrollPane);
				
				textArea = new JTextArea();
				textArea.setWrapStyleWord(true);
				textArea.setMargin(new Insets(10, 10, 10, 7));
				scrollPane.setViewportView(textArea);
				textArea.setLineWrap(true);
				textArea.setEditable(false);
				
			}
		});
		btnMostRead.setForeground(new Color(250, 250, 210));
		btnMostRead.setFont(new Font("Extreme", Font.BOLD, 20));
		btnMostRead.setBackground(new Color(0, 128, 128));
		panel_5.add(btnMostRead);
		btnMostRead.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnMostRead.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		
		btnTopNews = new JButton("Top News");
		btnTopNews.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				panel_1.setVisible(false);
				panel_2.setVisible(false);
								
				panel_36 = new JPanel();
				panel_36.setBackground(Color.BLACK);
				panel_36.setBounds(10, 123, 1331, 578);
				getContentPane().add(panel_36);
				panel_36.setLayout(null);
				
				scrollPane = new JScrollPane();
				scrollPane.setBounds(10, 63, 1311, 504);
				panel_36.add(scrollPane);
				
				textArea = new JTextArea();
				textArea.setWrapStyleWord(true);
				textArea.setMargin(new Insets(10, 10, 10, 7));
				scrollPane.setViewportView(textArea);
				textArea.setLineWrap(true);
				textArea.setEditable(false);
				
			}
		});
		btnTopNews.setForeground(new Color(250, 250, 210));
		btnTopNews.setFont(new Font("Extreme", Font.BOLD, 20));
		btnTopNews.setBackground(new Color(0, 128, 128));
		panel_5.add(btnTopNews);
		btnTopNews.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		
		
		ButtonHandler b=new ButtonHandler();
		btnWorld.addActionListener(b);
		btnMagazine.addActionListener(b);
		btnScience.addActionListener(b);
		btnPolitics.addActionListener(b);
		btnTechnology.addActionListener(b);
		btnEntertainment.addActionListener(b);
		btnSports.addActionListener(b);
		btnMostRead.addActionListener(b);
		btnPrimeTime.addActionListener(b);
		btnThisWeek.addActionListener(b);
		btnEducation.addActionListener(b);
		btnMoney.addActionListener(b);
		btnTravel.addActionListener(b);
		btnHealth.addActionListener(b);
		btnTopNews.addActionListener(b);
		btnBusiness.addActionListener(b);
		btnSearch.addActionListener(b);
		btnSignUp.addActionListener(b);
		btnSignIn.addActionListener(b);

	}catch(IOException ioe){
		System.out.println (" \n IO exception occured");
	}
		
		
}
	public class ButtonHandler implements ActionListener{
		
		Rss objrss = new Rss();
		ResultSet rs ;
		String field;
		public void actionPerformed(ActionEvent e){
			try{
				
				String news="";
				Connection connect= db2Connectivity.dbConnector();
				Statement stmt = connect.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
				if(e.getSource()!=btnSignUp && e.getSource()!=btnSignIn)
				{
					if(e.getSource()!=btnSearch){
				if(e.getSource()==btnWorld)
				{
					field="World News";
					rs = stmt.executeQuery("select Link from news where Field = 'World'");
			
				
					while(rs.next())
					{
						news +=objrss.readRSS("World",rs.getString(1));	
						setVisible(false);
					}
				
					
					
			     }
				else if(e.getSource()==btnBusiness)
				{
					field="Business News";
					rs = stmt.executeQuery("select Link from news where Field = 'Business'");
					
					while(rs.next())
					{
						news+=objrss.readRSS("Business",rs.getString(1));
						setVisible(false);
					}
									
			     }
				else if(e.getSource()==btnTopNews)
				{
					field="Top News";
					rs = stmt.executeQuery("select Link from news where Field='Top News'");
					while(rs.next())
					{
						news+=objrss.readRSS("Top News",rs.getString(1));
						setVisible(false);
					}
				
			     }
				
				else if(e.getSource()==btnSports){
					field="Sports News";
					rs = stmt.executeQuery("select Link from news where Field='Sports'");
					while(rs.next()){
						news+=objrss.readRSS("Sports",rs.getString(1));
						setVisible(false);
							}
				}
				
				else if(e.getSource()==btnPolitics){
					field="Politics News";
					rs = stmt.executeQuery("select Link from news where Field='Politics'");
					while(rs.next()){
						news+=objrss.readRSS("Politics",rs.getString(1));
						setVisible(false);
							}
					
				}
				
				else if(e.getSource()==btnTechnology){
					field="Technology News";
				    rs = stmt.executeQuery("select Link from news where Field='Technology'");
					while(rs.next()){
						news+=objrss.readRSS("Technology",rs.getString(1));
						setVisible(false);
							}
					
				}
				
				else if(e.getSource()==btnEntertainment){
					field="Entertainment News";
					rs = stmt.executeQuery("select Link from news where Field='Entertainment'");
					while(rs.next()){
						news+=objrss.readRSS("Entertainment",rs.getString(1));
						setVisible(false);
							}
					
				}
				
				else if(e.getSource()==btnEducation){
					field="Education News";
					rs = stmt.executeQuery("select Link from news where Field='Education'");
					while(rs.next()){
						news+=objrss.readRSS("Education",rs.getString(1));
						setVisible(false);
							}
					
				}
				
				else if(e.getSource()==btnMoney){
					field="Money News";
					rs = stmt.executeQuery("select Link from news where Field='Money'");
					while(rs.next()){
						news+=objrss.readRSS("Money",rs.getString(1));
						setVisible(false);
							}
					
				}
				
				else if(e.getSource()==btnTravel){
					field="Travel News";
					rs = stmt.executeQuery("select Link from news where Field='Travel'");
					while(rs.next()){
						news+=objrss.readRSS("Travel",rs.getString(1));
						setVisible(false);
							}
					
				}
				
				else if(e.getSource()==btnHealth){
					field="Health News";
					rs = stmt.executeQuery("select Link from news where Field='Health'");
					while(rs.next()){
						news+=objrss.readRSS("Health",rs.getString(1));
						setVisible(false);
							}
					
				}
				
				else if(e.getSource()==btnScience){
					field="Science News";
					rs = stmt.executeQuery("select Link from news where Field='Science'");
					while(rs.next()){
						news+=objrss.readRSS("Science",rs.getString(1));
						setVisible(false);
							}
				
				}
				
			
				else if(e.getSource()==btnMagazine){
					field="Magazine News";
					rs = stmt.executeQuery("select Link from news where Field='Magazine'");
					while(rs.next()){
						news+=objrss.readRSS("Magazine",rs.getString(1));
						setVisible(false);
							}
				
				}
				
				else if(e.getSource()==btnMostRead){
					field="Most Read News";
					rs = stmt.executeQuery("select Link from news where Field='Most Read Stories'");
					while(rs.next()){
						news+=objrss.readRSS("Most Read Stories",rs.getString(1));
						setVisible(false);
							}
					
				}
				
				else if(e.getSource()==btnPrimeTime){
					field="Primetime News";
					rs = stmt.executeQuery("select Link from news where Field='Primetime Headlines'");
					while(rs.next()){
						
						news+=objrss.readRSS("Primetime Headlines",rs.getString(1));
						setVisible(false);
							}
					
				}
				
				else if(e.getSource()==btnThisWeek){
					field="This Week Headlines";
					rs = stmt.executeQuery("select Link from news where Field='This Week Headlines'");
					while(rs.next()){
						news+=objrss.readRSS("This Week Headlines",rs.getString(1));
						setVisible(false);
							}
					
				}
				NewsResult newsUI=new NewsResult(news,field);
				newsUI.activate();
					}
					else{
					
					if(!textField_1.getText().isEmpty()){
						String search=textField_1.getText();
					rs=stmt.executeQuery("select * from Newsfeed where Title like '%" +search+"%'");
					while(rs.next()){
						news += "\n\n" + rs.getString(2) + "\n" + rs.getString(3) + "\n" + rs.getString(4) +"\n" ;
					}
					setVisible(false);
					NewsResult newsUI=new NewsResult(news,"");
					newsUI.activate();
					}
					else{
						JOptionPane.showMessageDialog(null,"Please enter something to search");
						
					}
				}
				
			}
				else{
				if(e.getSource()==btnSignUp){
					
					SignUp s=new SignUp();
					s.setVisible(true);
					
				}
				
				
			}
			}
			catch(SQLException ioe){
				
				System.out.println("Sql exception in UI");
			}
			
			catch(Exception m){
				
				System.out.println("ERROR!!!");
			}
		}
	
	}
	
	
		
	
}
